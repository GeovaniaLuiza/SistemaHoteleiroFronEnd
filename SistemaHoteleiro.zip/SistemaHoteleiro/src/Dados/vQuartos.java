/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dados;

/**
 *
 * @author Geovania
 */
public class vQuartos {
    
    private int id_quartos;
    private String numero;
    private String andar;
    private String descricao;
    private String caracteristica;
    private Double valor_diaria;
    private String estado;
    private String tipo_quarto;

    public vQuartos(int idQuartos, String numero, String andar, String descricao, String caracteristica, Double valorDiaria, String estado, String tipoQuarto) {
        this.id_quartos = idQuartos;
        this.numero = numero;
        this.andar = andar;
        this.descricao = descricao;
        this.caracteristica = caracteristica;
        this.valor_diaria = valor_diaria;
        this.estado = estado;
        this.tipo_quarto = tipo_quarto;
    }

    public vQuartos() {
        
    }

    public int getId_quartos() {
        return id_quartos;
    }

    public void setId_quartos(int id_quartos) {
        this.id_quartos = id_quartos;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getAndar() {
        return andar;
    }

    public void setAndar(String andar) {
        this.andar = andar;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(String caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Double getValor_diaria() {
        return valor_diaria;
    }

    public void setValor_diaria(Double valor_diaria) {
        this.valor_diaria = valor_diaria;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipo_quarto() {
        return tipo_quarto;
    }

    public void setTipo_quarto(String tipo_quarto) {
        this.tipo_quarto = tipo_quarto;
    }

    
    
}
