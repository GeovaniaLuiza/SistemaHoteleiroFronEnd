/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

/**
 *
 * @author Geovania
 */
public class fquartos {
    private conexao mysql = new conexao();
    private Connection cn = mysql.conetar();
    private String sSQL="";
    public Intereger totalRegistros;
    public DefaultTableModel mostrar(String buscar){
            
    DefaultTableModel modelo;
    String [] titulos {"ID","Numero", "Andar", "Descricao","Caracteristica",
    "Preco","Estado","TipoQuarto"}
    String[] registro = new String[8];
    totalregistros = 0;
  
    modelo = new DefaultTableModel (null, titulos);
    sSQL = "select * from tb_quartos where andar like '%" + buscar + "%'";
           
            try {
            Statement st = cn. createStatement();
            ResultSet rs = st.executeQuery(sSQL);
            while (rs.next());{
                registro [0] = rs.getString("id_quartos");
                registro [0] = rs.getString("numero");
                registro [0] = rs.getString("andar");
                registro [0] = rs.getString("descricao");
                registro [0] = rs.getString("caracteristica"); 
                registro [0] = rs.getString("estado");
                registro [0] = rs.getString("tipo_quarto");
                
                totalregistros = totalregistos + 1;
                    
            }
                
            } catch (Exception e) {
                
            
            } 
            
            
}
